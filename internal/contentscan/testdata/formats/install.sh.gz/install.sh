#!/bin/sh
echo single-file-marker
